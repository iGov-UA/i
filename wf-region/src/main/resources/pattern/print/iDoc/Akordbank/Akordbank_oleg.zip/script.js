// Script Oleg

var doc = document,
    getElByTagName = 'getElementsByTagName',
    createElement = doc.createElement('script'),
    add = doc[getElByTagName]('head')[0];

createElement.type = 'text/javascript';
createElement.charset = 'UTF-8';
createElement.async = true;
createElement.src = 'script.controller.js';
add.appendChild(createElement);