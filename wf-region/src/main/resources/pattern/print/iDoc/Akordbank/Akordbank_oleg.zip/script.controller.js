// Script Oleg

var t = $('.text'),
    s = $('span'),
    i = $('#spansDateRozp'),
    numberOtpravitelya = $('#sNumberOtpravitelya'), numberOtrymuvacha = $('#sNumberOtrymuvacha'), adressOtpravitelya = $('#sAdressOtpravitelya'), adressOtrymuvacha = $('#sAdressOtrymuvacha');

t.attr({
    'ng-app': 'myApp',
    'ng-controller': 'myCtrl'
    //'ng-repeat': 'x in records'
});
var arrayNumber = [ '1', '37', '38', '66', '7', '9', '10', '14', '18', '22', '2', '3', '5', '8', '11', '12', '15', '16', '17', '19', '20', '21', '23', '24', '25', '26', '27', '28', '30', '32', '33', '34', '39', '40', '41', '42', '42', '43', '44', '46', '47', '48', '51', '52', '53', '54', '56', '57', '58', '59', '60', '61', '64', '67', '68', '69', '70', '71', '72', '75' ], arrayAdress = [ 'm.Kyiv, pr. Golosiivscuy,93', 'm.Bila Cercva, vul.Levanevskogo,83', 'm.Kyiv, pr. Peremogi, 73/1', 'm.Kyiv, ���. Shevchenka, 62', 'm.Dnipro, vul. Brativ Trofimovih,40', 'm.Odessa, pr. Academika Glushka,14', 'm.Lviv, vul.Banderi,19', 'm.Kyiv, pr. Golosiivscuy, 98/2', 'm.Kyiv, vul.Dragomanova, 29-�', 'm.Kyiv, vul. Raisi Okipnoiy, 10', 'm.Hmelnicskiy, vul. Soborna, 69', 'm.Kyiv', 'm.Kyiv	vul. Borispilska, 11A', 'm.Dnipro vul. Titova,9', 'm.Kriviy Rig vul. Melekshina,22', 'm.Odessa vul. Preobrashenska, 66' ];
var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope)
{
    addSelect();
    addSelect_2();
    addButton();

    $('#mySelect').css({ 'margin-left': '20px' });
    $('#mySelect_2').css({ 'margin-left': '20px' });
    $('button').css({ 'margin-left': '20px' });

    $(document).ready(function ()
    {
        $('#mySelect').click(function ()
        {
            var random = Math.floor(Math.random() * (10 - 1 + 1)) + 10;
            $scope.textName = $('#mySelect').val();
            $scope.textAdress = '[' + arrayAdress[random] + ']';
            numberOtpravitelya.html('');
            adressOtpravitelya.html('');
            numberOtpravitelya.append($scope.textName);
            adressOtpravitelya.append($scope.textAdress);
            i.html('[sDateRegistration]');
        });
    });
    $(document).ready(function ()
    {
        $('#mySelect_2').click(function ()
        {
            var random = Math.floor(Math.random() * (10 - 1 + 1)) + 10;
            $scope.textName = $('#mySelect_2').val();
            $scope.textAdress = '[' + arrayAdress[random] + ']';
            numberOtrymuvacha.html('');
            adressOtrymuvacha.html('');
            numberOtrymuvacha.append($scope.textName);
            adressOtrymuvacha.append($scope.textAdress);
            i.html('[sDateRegistration]');
        });
    });
    $(document).ready(function ()
    {
        $('button').click(function ()
        {
            numberOtpravitelya.html('[sName_Brunches]');
            numberOtrymuvacha.html('[sName_OutBrunches]');
            adressOtpravitelya.html('[sID_Private_Source_Brunches]');
            adressOtrymuvacha.html('[sID_Private_Source_OutBrunches]');
        });
    });
});
function addButton()
{
    var button = document.createElement('button');
    var buttonValue = document.createTextNode('Stop');
    button.appendChild(buttonValue);
    document.body.appendChild(button);
}
function addSelect()
{
    var selectElement = document.createElement('select');
    selectElement.setAttribute('id', 'mySelect');
    document.body.appendChild(selectElement);

    for (i = 0; i < arrayNumber.length; ++i)
    {
        var option = document.createElement('option');
        var optionText = document.createTextNode('Viddilennya  ' + arrayNumber[i]);
        option.setAttribute('value', (arrayNumber[i]));
        option.appendChild(optionText);
        document.getElementById('mySelect').appendChild(option);
    }
}
function addSelect_2()
{
    var selectElement_2 = document.createElement('select');
    selectElement_2.setAttribute('id', 'mySelect_2');
    document.body.appendChild(selectElement_2);

    for (i = 0; i < arrayNumber.length; ++i)
    {
        var option_2 = document.createElement('option');
        var optionText_2 = document.createTextNode('Viddilennya  ' + arrayNumber[i]);
        option_2.setAttribute('value', (arrayNumber[i]));
        option_2.appendChild(optionText_2);
        document.getElementById('mySelect_2').appendChild(option_2);
    }
}