#!/bin/bash

sudo -K

res=$(eval "echo $1 | sudo -S whoami")

sudo -K

if [ "$res" == "root" ]; then
  exit 0
else
  exit 1
fi


