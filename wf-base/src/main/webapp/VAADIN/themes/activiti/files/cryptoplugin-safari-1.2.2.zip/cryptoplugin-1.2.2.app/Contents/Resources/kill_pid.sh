#!/bin/bash

LOG_DIR="${HOME}/.cryptoplugin"
LOG_FILE="${LOG_DIR}/install.log"

log() {
  echo $(date "+%Y-%m-%d %H.%M.%S ") $1 >> $LOG_FILE
}

kill_pid() {
  if [ "$1" != "" ]; then
    log "    kill $1"
    kill $1 || false
  fi
}

log "   Find process Firefox plugin-container"
PID_FIREFOX=$(ps xc | grep plugin-container | awk '{print $1}')
log "    Find pid plugin-container ${PID_FIREFOX}"

kill_pid "${PID_FIREFOX}"

PID_SAFARI=$(ps xc | grep WebKit.Plugin.64 | awk '{print $1}')
log "    Find pid sfari ${PID_SAFARI}"

kill_pid "${PID_SAFARI}"

log "   Find process nmcryptoplugin"
PID_NM=$(ps xc | grep nmcryptoplugin | awk '{print $1}')
log "    Find pid nmcryptoplugin ${PID_NM}"

kill_pid "${PID_NM}"

sudo -K

log "    finish kill_pid.sh"

exit 0