#!/bin/bash

ERROR_COPY_PLUGIN=1
ERROR_MKDIR_MANIFEST=2
ERROR_MKTEMP=3
ERROR_SET_PATH=4
ERROR_COPY_MANIFEST=5
ERROR_CHMOD_MANIFEST_DIR=6
ERROR_CHMOD_PLUGIN_DIR=7

ERROR_DELETE_PLUGIN=11
ERROR_DELETE_MANIFEST=12
ERROR_DELETE_ROOT_PLUGIN=13
ERROR_DELETE_ROOT_MANIFEST=14

LOG_DIR="${HOME}/.cryptoplugin"
LOG_FILE="${LOG_DIR}/install.log"

PLUGIN_DIR="${HOME}/Library/Internet Plug-Ins"
CHROME_MANIFEST_DIR="${HOME}/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MOZILLA_MANIFEST_DIR="${HOME}/Library/Application Support/Mozilla/NativeMessagingHosts"
MANIFEST_FILE="com.privatbank.cryptoplugin.json"

log() {
echo $(date "+%Y-%m-%d %H.%M.%S ") $1 >> $LOG_FILE
}

error_exit() {
log "   Error, $1"
exit $2
}

run_cms() {
log "   run: $1"
res=$(eval $1 2>&1)

if [ "${res}" != "" ] && [ "${res}" != "Password:" ]; then
log "   Error run command: ${res}"
exit $2
fi
}

BUNDLE_DIR="npcryptoplugin.bundle"
ROOT_MANIFEST_DIR="/Library/Google/Chrome/NativeMessagingHosts"
ROOT_PLUGIN_DIR="/Library/Internet Plug-Ins/npcryptoplugin.bundle"

mkdir -p $LOG_DIR

# user directory
if [ "$1" != "" ]; then
  log "   Uninstal local user with root premission"

  run_cms "echo \"$1\" | sudo -S chmod 0755 \"${PLUGIN_DIR}\"" $ERROR_CHMOD_PLUGIN_DIR

  if [ -d "${PLUGIN_DIR}/${BUNDLE_DIR}" ]; then
    run_cms "echo \"$1\" | sudo -S rm -rf \"${PLUGIN_DIR}/${BUNDLE_DIR}\"" $ERROR_DELETE_PLUGIN
  fi

  if [ -f "${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}" ]; then
    run_cms "echo \"$1\" | sudo -S rm -f \"${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_DELETE_MANIFEST
  fi

  if [ -f "${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}" ]; then
    run_cms "echo \"$1\" | sudo -S rm -f \"${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_DELETE_MANIFEST
  fi
else
  log "   Uninstal local user"
  if [ -d "${PLUGIN_DIR}/${BUNDLE_DIR}" ]; then
    run_cms "rm -rf \"${PLUGIN_DIR}/${BUNDLE_DIR}\"" $ERROR_DELETE_PLUGIN
  fi

  if [ -f "${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}" ]; then
    run_cms "rm -f \"${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_DELETE_MANIFEST
  fi

  if [ -f "${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}" ]; then
    run_cms "rm -f \"${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_DELETE_MANIFEST
  fi
fi

#root directory
if [ "$1" != "" ]; then
	log "   Uninstal root user"
    if [ -d "${ROOT_PLUGIN_DIR}" ]; then
	  run_cms "echo \"$1\" | sudo -S rm -rf \"${ROOT_PLUGIN_DIR}\"" $ERROR_DELETE_ROOT_PLUGIN
    fi

    if [ -f "${ROOT_MANIFEST_DIR}/${MANIFEST_FILE}" ]; then
	  run_cms "echo \"$1\" | sudo -S rm -f \"${ROOT_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_DELETE_ROOT_MANIFEST
    fi
fi

log "    finish remove.sh"

exit 0