#!/bin/bash

ERROR_COPY_PLUGIN=1
ERROR_MKDIR_MANIFEST=2
ERROR_MKTEMP=3
ERROR_SET_PATH=4
ERROR_COPY_MANIFEST=5
ERROR_CHMOD_MANIFEST_DIR=6
ERROR_CHMOD_PLUGIN_DIR=7

ERROR_DELETE_PLUGIN=11
ERROR_DELETE_MANIFEST=12
ERROR_DELETE_ROOT_PLUGIN=13
ERROR_DELETE_ROOT_MANIFEST=14

LOG_DIR="${HOME}/.cryptoplugin"
LOG_FILE="${LOG_DIR}/install.log"

PLUGIN_DIR="${HOME}/Library/Internet Plug-Ins"
CHROME_MANIFEST_DIR="${HOME}/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MOZILLA_MANIFEST_DIR="${HOME}/Library/Application Support/Mozilla/NativeMessagingHosts"
MANIFEST_FILE="com.privatbank.cryptoplugin.json"

log() {
echo $(date "+%Y-%m-%d %H.%M.%S ") $1 >> $LOG_FILE
}

error_exit() {
log "   Error, $1"
exit $2
}

run_cms() {
log "   run: $1"
res=$(eval $1 2>&1)

if [ "${res}" != "" ] && [ "${res}" != "Password:" ]; then
log "   Error run command: ${res}"
exit $2
fi
}

APP_DIR=$(dirname "$0")

INST_LIB="${PLUGIN_DIR}/npcryptoplugin.bundle/Contents/MacOS/nmcryptoplugin"
INST_LIB_UN=$(echo "${INST_LIB}" | sed 's/\//\\\//g')

mkdir -p $LOG_DIR

log "   System info: $(sw_vers)"
log "   Install local user"

if [ "$1" != "" ]; then
  run_cms "echo \"$1\" | sudo -S cp -r \"${APP_DIR}/npcryptoplugin.bundle\" \"${PLUGIN_DIR}\"" $ERROR_COPY_PLUGIN
else
  run_cms "cp -r \"${APP_DIR}/npcryptoplugin.bundle\" \"${PLUGIN_DIR}\"" $ERROR_COPY_PLUGIN
fi

if [ -d "$CHROME_MANIFEST_DIR" ]; then
  log "    Dir $CHROME_MANIFEST_DIR exist"
else
  run_cms "mkdir -p \"${CHROME_MANIFEST_DIR}\"" $ERROR_MKDIR_MANIFEST
fi

if [ -d "$MOZILLA_MANIFEST_DIR" ]; then
  log "    Dir $MOZILLA_MANIFEST_DIR exist"
else
  run_cms "mkdir -p \"${MOZILLA_MANIFEST_DIR}\"" $ERROR_MKDIR_MANIFEST
fi

log "   Create tmp dir"
TMP_DIR=$(mktemp -d -t cryptoplugin)

if [ -d "$TMP_DIR" ]; then
  log "    Created tmp dir $TMP_DIR"
else
  error_exit "tmp dir not exist" $ERROR_MKTEMP
fi

run_cms "sed \"s/PLUGIN_PATH/$INST_LIB_UN/g\" \"${PLUGIN_DIR}/npcryptoplugin.bundle/Contents/MacOS/chrome_${MANIFEST_FILE}\" > \"${TMP_DIR}/chrome_${MANIFEST_FILE}\"" $ERROR_SET_PATH
run_cms "sed \"s/PLUGIN_PATH/$INST_LIB_UN/g\" \"${PLUGIN_DIR}/npcryptoplugin.bundle/Contents/MacOS/mozilla_${MANIFEST_FILE}\" > \"${TMP_DIR}/mozilla_${MANIFEST_FILE}\"" $ERROR_SET_PATH

if [ -f "${TMP_DIR}/chrome_${MANIFEST_FILE}" ]; then
  log "    Path seted in file ${TMP_DIR}/chrome_${MANIFEST_FILE}"
else
  error_exit "path not set" $ERROR_SET_PATH
fi

if [ -f "${TMP_DIR}/mozilla_${MANIFEST_FILE}" ]; then
  log "    Path seted in file ${TMP_DIR}/mozilla_${MANIFEST_FILE}"
else
  error_exit "path not set" $ERROR_SET_PATH
fi

if [ "$1" != "" ]; then
  run_cms "echo \"$1\" | sudo -S cp -f \"${TMP_DIR}/chrome_${MANIFEST_FILE}\" \"${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_COPY_MANIFEST
  run_cms "echo \"$1\" | sudo -S cp -f \"${TMP_DIR}/mozilla_${MANIFEST_FILE}\" \"${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_COPY_MANIFEST
else
  run_cms "cp -f \"${TMP_DIR}/chrome_${MANIFEST_FILE}\" \"${CHROME_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_COPY_MANIFEST
  run_cms "cp -f \"${TMP_DIR}/mozilla_${MANIFEST_FILE}\" \"${MOZILLA_MANIFEST_DIR}/${MANIFEST_FILE}\"" $ERROR_COPY_MANIFEST
fi

run_cms "rm -rf \"$TMP_DIR\"" 0

sudo -K

log "    finish install.sh"

exit 0