ERROR_COPY_PLUGIN=1
ERROR_MKDIR_MANIFEST=2
ERROR_MKTEMP=3
ERROR_SET_PATH=4
ERROR_COPY_MANIFEST=5
ERROR_CHMOD_MANIFEST_DIR=6
ERROR_CHMOD_PLUGIN_DIR=7

ERROR_DELETE_PLUGIN=11
ERROR_DELETE_MANIFEST=12
ERROR_DELETE_ROOT_PLUGIN=13
ERROR_DELETE_ROOT_MANIFEST=14

LOG_DIR="${HOME}/.cryptoplugin"
LOG_FILE="${LOG_DIR}/install.log"

PLUGIN_DIR="${HOME}/Library/Internet Plug-Ins"
MANIFEST_DIR="${HOME}/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MANIFEST_FILE="com.privatbank.cryptoplugin.json"

log() {
  echo $(date "+%Y-%m-%d %H.%M.%S ") $1 >> $LOG_FILE
}

error_exit() {
  log "   Error, $1"
  exit $2
}

run_cms() {
  log "   run: $1"
  res=$(eval $1 2>&1)

  if [ "${res}" != "" ]; then
    log "   Error run command: ${res}"
    exit $2
  fi
}